import torch
from typing import * 

    torque = action * state_dict['torques'].data  # Scale by a predefined scale if required
    return torque



